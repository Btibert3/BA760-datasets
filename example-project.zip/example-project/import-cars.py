import pandas as pd
cars = pd.read_csv("cars.csv")
cars.head()
